<template>
  <v-container fluid>
    <v-layout row wrap>
      <Heading :title="$t('errors.404')" />
    </v-layout>
  </v-container>
</template>
